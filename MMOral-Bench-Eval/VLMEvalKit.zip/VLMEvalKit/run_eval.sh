python run.py --config gpt_config.json
