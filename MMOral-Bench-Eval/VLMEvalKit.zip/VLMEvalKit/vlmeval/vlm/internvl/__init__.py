from .internvl_chat import InternVLChat

__all__ = ['InternVLChat']
